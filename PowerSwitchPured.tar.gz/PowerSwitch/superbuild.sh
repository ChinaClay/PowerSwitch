gradle assembleRelease && ./sign.sh
